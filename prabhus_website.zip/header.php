<?php
/**
 * Header Template for Prabhu's Flutes Website
 *
 * @package Prabhus_Website
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Top Announcement Bar -->
<div class="top-announcement">
	✨ Handcrafted Assam Bamboo Flutes | Precision 440Hz & 432Hz Concert Tuning | Free Express Worldwide Shipping
</div>

<!-- Header -->
<header class="site-header" id="site-header">
	<div class="container header-inner">
		
		<!-- Brand Logo -->
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo" title="Prabhu's Flutes Home">
			<div class="brand-logo-icon">🪈</div>
			<div>
				<div class="brand-title">PRABHU'S</div>
				<span class="brand-subtitle">FLUTES & INSTRUMENTS</span>
			</div>
		</a>

		<!-- Main Navigation -->
		<nav class="main-nav">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-link active">Home</a>
			<a href="#featured-flutes" class="nav-link">Shop Flutes</a>
			<a href="#scale-finder" class="nav-link">Scale Finder</a>
			<a href="#audio-preview" class="nav-link">Listen Sound Samples</a>
			<a href="#craftsmanship" class="nav-link">Our Craft</a>
			<a href="#contact" class="nav-link">Contact</a>
		</nav>

		<!-- Header Actions -->
		<div class="header-actions">
			<!-- Sound Sample Quick Button -->
			<a href="#audio-preview" class="btn btn-outline btn-sm d-none-mobile">
				<span class="pulse-dot"></span> Audio Preview
			</a>

			<!-- Cart Button -->
			<button class="icon-btn" id="open-cart-btn" aria-label="View Shopping Cart">
				🛒
				<span class="cart-badge" id="cart-count">
					<?php echo class_exists( 'WooCommerce' ) && WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : '2'; ?>
				</span>
			</button>
		</div>

	</div>
</header>
