/**
 * Prabhu's Flutes - Theme JavaScript
 * Includes Web Audio API Flute Sound Previewer, Slide-out Cart Drawer, and UI micro-interactions.
 */

document.addEventListener('DOMContentLoaded', () => {
  /* ==========================================================================
     1. WEB AUDIO API FLUTE SOUND SYNTHESIZER
     ========================================================================== */
  let audioCtx = null;
  let currentOsc = null;
  let currentGain = null;
  let isPlaying = false;

  const playBtn = document.getElementById('play-flute-audio');
  const scaleButtons = document.querySelectorAll('#scale-sound-selector .scale-btn');
  const playingTitle = document.getElementById('current-playing-title');
  const playingFreq = document.getElementById('current-playing-freq');

  let activeFreq = 329.63; // Default E Natural
  let activeTitle = 'E Natural Medium';

  scaleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      scaleButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      activeFreq = parseFloat(btn.dataset.freq);
      activeTitle = btn.dataset.scale;

      if (playingTitle) playingTitle.textContent = activeTitle;
      if (playingFreq) playingFreq.textContent = activeFreq + 'Hz Frequency';

      if (isPlaying) {
        stopFluteTone();
        playFluteTone(activeFreq);
      }
    });
  });

  if (playBtn) {
    playBtn.addEventListener('click', () => {
      if (!isPlaying) {
        playFluteTone(activeFreq);
        playBtn.innerHTML = '❚❚';
        playBtn.style.background = 'var(--color-primary-light)';
        isPlaying = true;
      } else {
        stopFluteTone();
        playBtn.innerHTML = '▶';
        playBtn.style.background = 'var(--color-primary)';
        isPlaying = false;
      }
    });
  }

  function playFluteTone(freq) {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!audioCtx) {
        audioCtx = new AudioContext();
      }

      // Main harmonic oscillator (warm sine wave mimicking bamboo resonance)
      currentOsc = audioCtx.createOscillator();
      const subOsc = audioCtx.createOscillator();
      currentGain = audioCtx.createGain();

      currentOsc.type = 'sine';
      currentOsc.frequency.setValueAtTime(freq, audioCtx.currentTime);

      subOsc.type = 'triangle';
      subOsc.frequency.setValueAtTime(freq * 2, audioCtx.currentTime); // Octave overtone

      // Soft envelope for smooth acoustic attack
      currentGain.gain.setValueAtTime(0.01, audioCtx.currentTime);
      currentGain.gain.exponentialRampToValueAtTime(0.3, audioCtx.currentTime + 0.3);

      const subGain = audioCtx.createGain();
      subGain.gain.setValueAtTime(0.08, audioCtx.currentTime);

      currentOsc.connect(currentGain);
      subOsc.connect(subGain);
      subGain.connect(currentGain);
      currentGain.connect(audioCtx.destination);

      currentOsc.start();
      subOsc.start();
    } catch (e) {
      console.log('Web Audio API not allowed without user gesture:', e);
    }
  }

  function stopFluteTone() {
    if (currentGain && audioCtx) {
      currentGain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
      setTimeout(() => {
        if (currentOsc) {
          try { currentOsc.stop(); } catch(e){}
        }
      }, 200);
    }
  }

  /* ==========================================================================
     2. CART DRAWER & AJAX SIMULATION
     ========================================================================== */
  const openCartBtn = document.getElementById('open-cart-btn');
  const closeCartBtn = document.getElementById('close-cart-btn');
  const cartBackdrop = document.getElementById('cart-backdrop');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartBadge = document.getElementById('cart-count');
  const addToCartBtns = document.querySelectorAll('.add-to-cart-trigger');

  function openCart() {
    if (cartDrawer && cartBackdrop) {
      cartDrawer.classList.add('active');
      cartBackdrop.classList.add('active');
    }
  }

  function closeCart() {
    if (cartDrawer && cartBackdrop) {
      cartDrawer.classList.remove('active');
      cartBackdrop.classList.remove('active');
    }
  }

  if (openCartBtn) openCartBtn.addEventListener('click', openCart);
  if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
  if (cartBackdrop) cartBackdrop.addEventListener('click', closeCart);

  addToCartBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const currentCount = parseInt(cartBadge.textContent || '0');
      cartBadge.textContent = currentCount + 1;
      
      // Flash button feedback
      const origText = btn.innerHTML;
      btn.innerHTML = 'Added! ✓';
      btn.style.background = 'var(--color-accent-green)';
      btn.style.color = '#fff';

      setTimeout(() => {
        btn.innerHTML = origText;
        btn.style.background = '';
        btn.style.color = '';
        openCart();
      }, 600);
    });
  });

  /* ==========================================================================
     3. STICKY HEADER SCROLL EFFECT
     ========================================================================== */
  const header = document.getElementById('site-header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.style.boxShadow = 'var(--shadow-md)';
    } else {
      header.style.boxShadow = 'none';
    }
  });
});
