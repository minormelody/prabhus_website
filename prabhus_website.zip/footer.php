<?php
/**
 * Footer Template for Prabhu's Flutes Website
 *
 * @package Prabhus_Website
 */
?>

<!-- Slide-out Cart Drawer Overlay -->
<div class="cart-drawer-backdrop" id="cart-backdrop"></div>
<div class="cart-drawer" id="cart-drawer">
	<div class="cart-drawer-header">
		<h3>Shopping Cart</h3>
		<button class="icon-btn" id="close-cart-btn" aria-label="Close Cart">&times;</button>
	</div>
	<div class="cart-drawer-body" id="cart-drawer-items">
		<!-- Cart Item Preview 1 -->
		<div class="cart-item">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/flute_e_natural.png' ); ?>" alt="Prabhu Concert Bansuri E Natural" class="cart-item-img">
			<div class="cart-item-details">
				<h5>Prabhu Concert Bansuri - E Natural Medium</h5>
				<p class="text-gold" style="font-size:0.8rem; margin-bottom:0.2rem;">Scale: E Natural (440Hz)</p>
				<div class="cart-item-price">1 × ₹2,499</div>
			</div>
		</div>
		<!-- Cart Item Preview 2 -->
		<div class="cart-item">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/flute_accessory.png' ); ?>" alt="Flute Bag" class="cart-item-img">
			<div class="cart-item-details">
				<h5>Padded Canvas Flute Carry Case</h5>
				<p class="text-gold" style="font-size:0.8rem; margin-bottom:0.2rem;">Protection: Velvet Lined</p>
				<div class="cart-item-price">1 × ₹799</div>
			</div>
		</div>
	</div>
	<div class="cart-drawer-footer">
		<div class="cart-subtotal-row">
			<span>Subtotal:</span>
			<span class="text-gold">₹3,298</span>
		</div>
		<p style="font-size:0.8rem; color:var(--color-text-muted); margin-bottom:1rem;">Taxes and shipping calculated at checkout.</p>
		<a href="<?php echo class_exists('WooCommerce') ? esc_url( wc_get_checkout_url() ) : '#checkout'; ?>" class="btn btn-primary" style="width:100%;">
			Proceed to Secure Checkout 🔒
		</a>
	</div>
</div>

<!-- Main Footer -->
<footer class="site-footer" id="contact">
	<div class="container">
		<div class="footer-grid">
			<!-- Brand Info -->
			<div class="footer-brand">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo" style="margin-bottom:1rem;">
					<div class="brand-logo-icon">🪈</div>
					<div>
						<div class="brand-title">PRABHU'S</div>
						<span class="brand-subtitle">FLUTES & INSTRUMENTS</span>
					</div>
				</a>
				<p>Crafting master-grade Indian Bansuri and concert flutes using seasoned Assam bamboo. Tuned to perfection for professional musicians, disciples, and enthusiasts worldwide.</p>
			</div>

			<!-- Quick Links -->
			<div class="footer-column">
				<h4>Shop Categories</h4>
				<ul class="footer-links">
					<li><a href="#featured-flutes">Medium Bansuri Flutes</a></li>
					<li><a href="#featured-flutes">Deep Bass Flutes</a></li>
					<li><a href="#featured-flutes">Beginner Flute Sets</a></li>
					<li><a href="#featured-flutes">Flute Carrying Bags</a></li>
					<li><a href="#featured-flutes">Maintenance Beeswax</a></li>
				</ul>
			</div>

			<!-- Customer Care -->
			<div class="footer-column">
				<h4>Customer Support</h4>
				<ul class="footer-links">
					<li><a href="#scale-finder">Flute Scale Guide</a></li>
					<li><a href="#audio-preview">Listen Sound Clips</a></li>
					<li><a href="#shipping">Worldwide Shipping</a></li>
					<li><a href="#returns">7-Day Return & Replacement</a></li>
					<li><a href="#custom-order">Request Custom Pitch Tuning</a></li>
				</ul>
			</div>

			<!-- Contact & Hostinger Guarantee -->
			<div class="footer-column">
				<h4>Get In Touch</h4>
				<p style="font-size:0.9rem; margin-bottom:0.5rem;">📍 Assam & New Delhi, India</p>
				<p style="font-size:0.9rem; margin-bottom:0.5rem;">📞 +91 98765 43210</p>
				<p style="font-size:0.9rem; margin-bottom:1rem;">✉️ support@prabhusflutes.com</p>
				
				<div style="background:var(--color-bg-card); padding:0.8rem; border-radius:var(--radius-sm); border:1px solid var(--color-border); font-size:0.75rem;">
					🔒 Powered by Hostinger Secure SSL & WooCommerce Lightning Checkout
				</div>
			</div>
		</div>

		<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div>
				&copy; <?php echo date('Y'); ?> Prabhu's Flutes. All rights reserved. Designed for Hostinger Deployment.
			</div>
			<div style="display:flex; gap:1.5rem;">
				<a href="#">Privacy Policy</a>
				<a href="#">Terms of Service</a>
				<a href="#">Refund Policy</a>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
